/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Modelo;

import java.io.Serializable;
import java.util.Collection;
import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlTransient;

/**
 *
 * @author ygome
 */
@Entity
@Table(name = "equipos")
@XmlRootElement
@NamedQueries({
    @NamedQuery(name = "Equipos.findAll", query = "SELECT e FROM Equipos e")
    , @NamedQuery(name = "Equipos.findByNombre", query = "SELECT e FROM Equipos e WHERE e.nombre = :nombre")
    , @NamedQuery(name = "Equipos.findByCiudad", query = "SELECT e FROM Equipos e WHERE e.ciudad = :ciudad")
    , @NamedQuery(name = "Equipos.findByConferencia", query = "SELECT e FROM Equipos e WHERE e.conferencia = :conferencia")
    , @NamedQuery(name = "Equipos.findByDivision", query = "SELECT e FROM Equipos e WHERE e.division = :division")
    , @NamedQuery(name = "Equipos.ConfDiv", query = "SELECT distinct e.division FROM Equipos e WHERE e.conferencia = :conf")
    , @NamedQuery(name = "Equipos.DivEquipo", query = "SELECT e.nombre FROM Equipos e WHERE e.division = :div")
})
public class Equipos implements Serializable {

    private static final long serialVersionUID = 1L;
    @Id
    @Basic(optional = false)
    @NotNull
    @Size(min = 1, max = 20)
    @Column(name = "Nombre")
    private String nombre;
    @Size(max = 20)
    @Column(name = "Ciudad")
    private String ciudad;
    @Size(max = 4)
    @Column(name = "Conferencia")
    private String conferencia;
    @Size(max = 9)
    @Column(name = "Division")
    private String division;
    @OneToMany(mappedBy = "nombreequipo")
    private Collection<Jugadores> jugadoresCollection;
    @OneToMany(mappedBy = "equipoLocal")
    private Collection<Partidos> partidosCollection;
    @OneToMany(mappedBy = "equipoVisitante")
    private Collection<Partidos> partidosCollection1;

    public Equipos() {
    }

    public Equipos(String nombre) {
        this.nombre = nombre;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getCiudad() {
        return ciudad;
    }

    public void setCiudad(String ciudad) {
        this.ciudad = ciudad;
    }

    public String getConferencia() {
        return conferencia;
    }

    public void setConferencia(String conferencia) {
        this.conferencia = conferencia;
    }

    public String getDivision() {
        return division;
    }

    public void setDivision(String division) {
        this.division = division;
    }

    @XmlTransient
    public Collection<Jugadores> getJugadoresCollection() {
        return jugadoresCollection;
    }

    public void setJugadoresCollection(Collection<Jugadores> jugadoresCollection) {
        this.jugadoresCollection = jugadoresCollection;
    }

    @XmlTransient
    public Collection<Partidos> getPartidosCollection() {
        return partidosCollection;
    }

    public void setPartidosCollection(Collection<Partidos> partidosCollection) {
        this.partidosCollection = partidosCollection;
    }

    @XmlTransient
    public Collection<Partidos> getPartidosCollection1() {
        return partidosCollection1;
    }

    public void setPartidosCollection1(Collection<Partidos> partidosCollection1) {
        this.partidosCollection1 = partidosCollection1;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (nombre != null ? nombre.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof Equipos)) {
            return false;
        }
        Equipos other = (Equipos) object;
        if ((this.nombre == null && other.nombre != null) || (this.nombre != null && !this.nombre.equals(other.nombre))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "Modelo.Equipos[ nombre=" + nombre + " ]";
    }

}
