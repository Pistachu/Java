/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Modelo;

import java.io.Serializable;
import java.util.Collection;
import javax.persistence.Basic;
import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlTransient;

/**
 *
 * @author ygome
 */
@Entity
@Table(name = "jugadores")
@XmlRootElement
@NamedQueries({
    @NamedQuery(name = "Jugadores.findAll", query = "SELECT j FROM Jugadores j")
    , @NamedQuery(name = "Jugadores.findByCodigo", query = "SELECT j FROM Jugadores j WHERE j.codigo = :codigo")
    , @NamedQuery(name = "Jugadores.findByNombre", query = "SELECT j FROM Jugadores j WHERE j.nombre = :nombre")
    , @NamedQuery(name = "Jugadores.findByProcedencia", query = "SELECT j FROM Jugadores j WHERE j.procedencia = :procedencia")
    , @NamedQuery(name = "Jugadores.findByAltura", query = "SELECT j FROM Jugadores j WHERE j.altura = :altura")
    , @NamedQuery(name = "Jugadores.findByPeso", query = "SELECT j FROM Jugadores j WHERE j.peso = :peso")
    , @NamedQuery(name = "Jugadores.findByPosicion", query = "SELECT j FROM Jugadores j WHERE j.posicion = :posicion")
    , @NamedQuery(name = "Jugadores.EquipoJug", query = "SELECT j.nombre, j.procedencia, j.altura, j.peso, j.posicion FROM Jugadores j WHERE j.nombreequipo.nombre = :equipo")
})
public class Jugadores implements Serializable {

    private static final long serialVersionUID = 1L;
    @Id
    @Basic(optional = false)
    @NotNull
    @Column(name = "codigo")
    private Integer codigo;
    @Size(max = 30)
    @Column(name = "Nombre")
    private String nombre;
    @Size(max = 20)
    @Column(name = "Procedencia")
    private String procedencia;
    @Size(max = 4)
    @Column(name = "Altura")
    private String altura;
    @Column(name = "Peso")
    private Integer peso;
    @Size(max = 5)
    @Column(name = "Posicion")
    private String posicion;
    @OneToMany(cascade = CascadeType.ALL, mappedBy = "jugadores")
    private Collection<Estadisticas> estadisticasCollection;
    @JoinColumn(name = "Nombre_equipo", referencedColumnName = "Nombre")
    @ManyToOne
    private Equipos nombreequipo;

    public Jugadores() {
    }

    public Jugadores(Integer codigo) {
        this.codigo = codigo;
    }

    public Integer getCodigo() {
        return codigo;
    }

    public void setCodigo(Integer codigo) {
        this.codigo = codigo;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getProcedencia() {
        return procedencia;
    }

    public void setProcedencia(String procedencia) {
        this.procedencia = procedencia;
    }

    public String getAltura() {
        return altura;
    }

    public void setAltura(String altura) {
        this.altura = altura;
    }

    public Integer getPeso() {
        return peso;
    }

    public void setPeso(Integer peso) {
        this.peso = peso;
    }

    public String getPosicion() {
        return posicion;
    }

    public void setPosicion(String posicion) {
        this.posicion = posicion;
    }

    @XmlTransient
    public Collection<Estadisticas> getEstadisticasCollection() {
        return estadisticasCollection;
    }

    public void setEstadisticasCollection(Collection<Estadisticas> estadisticasCollection) {
        this.estadisticasCollection = estadisticasCollection;
    }

    public Equipos getNombreequipo() {
        return nombreequipo;
    }

    public void setNombreequipo(Equipos nombreequipo) {
        this.nombreequipo = nombreequipo;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (codigo != null ? codigo.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof Jugadores)) {
            return false;
        }
        Jugadores other = (Jugadores) object;
        if ((this.codigo == null && other.codigo != null) || (this.codigo != null && !this.codigo.equals(other.codigo))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "Modelo.Jugadores[ codigo=" + codigo + " ]";
    }

}
