/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Modelo;

import java.io.Serializable;
import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Embeddable;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;

/**
 *
 * @author ygome
 */
@Embeddable
public class EstadisticasPK implements Serializable {

    @Basic(optional = false)
    @NotNull
    @Size(min = 1, max = 5)
    @Column(name = "temporada")
    private String temporada;
    @Basic(optional = false)
    @NotNull
    @Column(name = "jugador")
    private int jugador;

    public EstadisticasPK() {
    }

    public EstadisticasPK(String temporada, int jugador) {
        this.temporada = temporada;
        this.jugador = jugador;
    }

    public String getTemporada() {
        return temporada;
    }

    public void setTemporada(String temporada) {
        this.temporada = temporada;
    }

    public int getJugador() {
        return jugador;
    }

    public void setJugador(int jugador) {
        this.jugador = jugador;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (temporada != null ? temporada.hashCode() : 0);
        hash += (int) jugador;
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof EstadisticasPK)) {
            return false;
        }
        EstadisticasPK other = (EstadisticasPK) object;
        if ((this.temporada == null && other.temporada != null) || (this.temporada != null && !this.temporada.equals(other.temporada))) {
            return false;
        }
        if (this.jugador != other.jugador) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "Modelo.EstadisticasPK[ temporada=" + temporada + ", jugador=" + jugador + " ]";
    }
    
}
