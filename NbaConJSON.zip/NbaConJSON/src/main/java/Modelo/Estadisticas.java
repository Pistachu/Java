/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Modelo;

import java.io.Serializable;
import javax.persistence.Column;
import javax.persistence.EmbeddedId;
import javax.persistence.Entity;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;
import javax.xml.bind.annotation.XmlRootElement;

/**
 *
 * @author ygome
 */
@Entity
@Table(name = "estadisticas")
@XmlRootElement
@NamedQueries({
    @NamedQuery(name = "Estadisticas.findAll", query = "SELECT e FROM Estadisticas e")
    , @NamedQuery(name = "Estadisticas.findByTemporada", query = "SELECT e FROM Estadisticas e WHERE e.estadisticasPK.temporada = :temporada")
    , @NamedQuery(name = "Estadisticas.findByJugador", query = "SELECT e FROM Estadisticas e WHERE e.estadisticasPK.jugador = :jugador")
    , @NamedQuery(name = "Estadisticas.findByPuntosporpartido", query = "SELECT e FROM Estadisticas e WHERE e.puntosporpartido = :puntosporpartido")
    , @NamedQuery(name = "Estadisticas.findByAsistenciasporpartido", query = "SELECT e FROM Estadisticas e WHERE e.asistenciasporpartido = :asistenciasporpartido")
    , @NamedQuery(name = "Estadisticas.findByTaponesporpartido", query = "SELECT e FROM Estadisticas e WHERE e.taponesporpartido = :taponesporpartido")
    , @NamedQuery(name = "Estadisticas.findByRebotesporpartido", query = "SELECT e FROM Estadisticas e WHERE e.rebotesporpartido = :rebotesporpartido")})
public class Estadisticas implements Serializable {

    private static final long serialVersionUID = 1L;
    @EmbeddedId
    protected EstadisticasPK estadisticasPK;
    // @Max(value=?)  @Min(value=?)//if you know range of your decimal fields consider using these annotations to enforce field validation
    @Column(name = "Puntos_por_partido")
    private Float puntosporpartido;
    @Column(name = "Asistencias_por_partido")
    private Float asistenciasporpartido;
    @Column(name = "Tapones_por_partido")
    private Float taponesporpartido;
    @Column(name = "Rebotes_por_partido")
    private Float rebotesporpartido;
    @JoinColumn(name = "jugador", referencedColumnName = "codigo", insertable = false, updatable = false)
    @ManyToOne(optional = false)
    private Jugadores jugadores;

    public Estadisticas() {
    }

    public Estadisticas(EstadisticasPK estadisticasPK) {
        this.estadisticasPK = estadisticasPK;
    }

    public Estadisticas(String temporada, int jugador) {
        this.estadisticasPK = new EstadisticasPK(temporada, jugador);
    }

    public EstadisticasPK getEstadisticasPK() {
        return estadisticasPK;
    }

    public void setEstadisticasPK(EstadisticasPK estadisticasPK) {
        this.estadisticasPK = estadisticasPK;
    }

    public Float getPuntosporpartido() {
        return puntosporpartido;
    }

    public void setPuntosporpartido(Float puntosporpartido) {
        this.puntosporpartido = puntosporpartido;
    }

    public Float getAsistenciasporpartido() {
        return asistenciasporpartido;
    }

    public void setAsistenciasporpartido(Float asistenciasporpartido) {
        this.asistenciasporpartido = asistenciasporpartido;
    }

    public Float getTaponesporpartido() {
        return taponesporpartido;
    }

    public void setTaponesporpartido(Float taponesporpartido) {
        this.taponesporpartido = taponesporpartido;
    }

    public Float getRebotesporpartido() {
        return rebotesporpartido;
    }

    public void setRebotesporpartido(Float rebotesporpartido) {
        this.rebotesporpartido = rebotesporpartido;
    }

    public Jugadores getJugadores() {
        return jugadores;
    }

    public void setJugadores(Jugadores jugadores) {
        this.jugadores = jugadores;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (estadisticasPK != null ? estadisticasPK.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof Estadisticas)) {
            return false;
        }
        Estadisticas other = (Estadisticas) object;
        if ((this.estadisticasPK == null && other.estadisticasPK != null) || (this.estadisticasPK != null && !this.estadisticasPK.equals(other.estadisticasPK))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "Modelo.Estadisticas[ estadisticasPK=" + estadisticasPK + " ]";
    }
    
}
